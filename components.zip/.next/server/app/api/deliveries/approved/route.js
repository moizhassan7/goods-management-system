var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/deliveries/approved/route.js")
R.c("server/chunks/[root-of-the-server]__1b5a43b3._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(57621)
R.m(69918)
module.exports=R.m(69918).exports
