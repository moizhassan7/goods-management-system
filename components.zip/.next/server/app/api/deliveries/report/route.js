var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/deliveries/report/route.js")
R.c("server/chunks/[root-of-the-server]__91072824._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(43320)
R.m(19227)
module.exports=R.m(19227).exports
