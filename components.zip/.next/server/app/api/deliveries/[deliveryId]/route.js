var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/deliveries/[deliveryId]/route.js")
R.c("server/chunks/[root-of-the-server]__7608b00e._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(32109)
R.m(79489)
module.exports=R.m(79489).exports
