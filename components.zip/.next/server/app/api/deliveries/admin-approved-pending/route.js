var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/deliveries/admin-approved-pending/route.js")
R.c("server/chunks/[root-of-the-server]__a9754c48._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.c("server/chunks/[root-of-the-server]__0661a30d._.js")
R.m(88657)
R.m(61970)
module.exports=R.m(61970).exports
