var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/deliveries/pending-approvals/route.js")
R.c("server/chunks/[root-of-the-server]__a35344cf._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(35104)
R.m(58039)
module.exports=R.m(58039).exports
