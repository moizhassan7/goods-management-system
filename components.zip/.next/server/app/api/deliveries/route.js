var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/deliveries/route.js")
R.c("server/chunks/[root-of-the-server]__8467df1d._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(17380)
R.m(73589)
module.exports=R.m(73589).exports
