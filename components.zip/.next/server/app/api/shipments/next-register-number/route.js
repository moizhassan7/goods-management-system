var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shipments/next-register-number/route.js")
R.c("server/chunks/[root-of-the-server]__6e4909de._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(43226)
R.m(32932)
module.exports=R.m(32932).exports
