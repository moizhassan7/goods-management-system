var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shipments/view-all/route.js")
R.c("server/chunks/[root-of-the-server]__50402320._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(6218)
R.m(8723)
module.exports=R.m(8723).exports
