var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/shipments/route.js")
R.c("server/chunks/[root-of-the-server]__28bb14a2._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(55825)
R.m(52860)
module.exports=R.m(52860).exports
