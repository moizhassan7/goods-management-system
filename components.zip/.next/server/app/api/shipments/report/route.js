var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shipments/report/route.js")
R.c("server/chunks/[root-of-the-server]__8dc1e8e8._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(76666)
R.m(395)
module.exports=R.m(395).exports
