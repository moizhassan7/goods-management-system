var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shipments/by-vehicle-date/route.js")
R.c("server/chunks/[root-of-the-server]__1db91c11._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(69244)
R.m(64419)
module.exports=R.m(64419).exports
