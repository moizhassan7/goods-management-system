var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shipments/[shipmentId]/route.js")
R.c("server/chunks/[root-of-the-server]__f4fcb7cb._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(15621)
R.m(85797)
module.exports=R.m(85797).exports
