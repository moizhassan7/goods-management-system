var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/vehicles/[id]/settle-fare/route.js")
R.c("server/chunks/[root-of-the-server]__e09169a0._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(6364)
R.m(2420)
module.exports=R.m(2420).exports
