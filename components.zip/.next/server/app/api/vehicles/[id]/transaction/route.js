var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/vehicles/[id]/transaction/route.js")
R.c("server/chunks/[root-of-the-server]__6894f48d._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(71823)
R.m(12809)
module.exports=R.m(12809).exports
