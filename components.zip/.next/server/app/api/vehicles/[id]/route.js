var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/vehicles/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__3e0de01a._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(9013)
R.m(10574)
module.exports=R.m(10574).exports
