var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/vehicles/[id]/financials/route.js")
R.c("server/chunks/[root-of-the-server]__433c8b46._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(1073)
R.m(58739)
module.exports=R.m(58739).exports
