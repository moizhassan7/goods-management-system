var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/vehicles/route.js")
R.c("server/chunks/[root-of-the-server]__d1605541._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(78360)
R.m(85176)
module.exports=R.m(85176).exports
