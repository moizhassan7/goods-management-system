var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/items/route.js")
R.c("server/chunks/[root-of-the-server]__12cfe73f._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(20630)
R.m(50079)
module.exports=R.m(50079).exports
