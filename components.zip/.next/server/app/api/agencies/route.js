var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/agencies/route.js")
R.c("server/chunks/[root-of-the-server]__2d5f2f9c._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.c("server/chunks/[root-of-the-server]__0661a30d._.js")
R.m(75506)
R.m(81069)
module.exports=R.m(81069).exports
