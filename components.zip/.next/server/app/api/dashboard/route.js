var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__2644bdd3._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(84585)
R.m(70171)
module.exports=R.m(70171).exports
