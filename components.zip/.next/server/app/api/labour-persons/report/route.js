var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/labour-persons/report/route.js")
R.c("server/chunks/[root-of-the-server]__c9606085._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(81316)
R.m(78286)
module.exports=R.m(78286).exports
