var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/labour-persons/route.js")
R.c("server/chunks/[root-of-the-server]__a0507c8b._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(86496)
R.m(30702)
module.exports=R.m(30702).exports
