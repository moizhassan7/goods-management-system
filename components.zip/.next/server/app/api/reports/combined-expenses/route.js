var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/combined-expenses/route.js")
R.c("server/chunks/[root-of-the-server]__212ac02e._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(38748)
R.m(73123)
module.exports=R.m(73123).exports
