var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/returns/route.js")
R.c("server/chunks/[root-of-the-server]__44128ca8._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(51583)
R.m(62765)
module.exports=R.m(62765).exports
