var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/parties/route.js")
R.c("server/chunks/[root-of-the-server]__7a163e25._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(59604)
R.m(63955)
module.exports=R.m(63955).exports
