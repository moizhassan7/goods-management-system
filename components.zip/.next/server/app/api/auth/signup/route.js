var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/signup/route.js")
R.c("server/chunks/[root-of-the-server]__2ebf1cea._.js")
R.c("server/chunks/[root-of-the-server]__0661a30d._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.c("server/chunks/c4e26_zod_v4_classic_schemas_38dfecf8.js")
R.m(69028)
R.m(96515)
module.exports=R.m(96515).exports
