var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/session/route.js")
R.c("server/chunks/[root-of-the-server]__9d3d9087._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.c("server/chunks/[root-of-the-server]__0661a30d._.js")
R.m(46776)
R.m(42478)
module.exports=R.m(42478).exports
