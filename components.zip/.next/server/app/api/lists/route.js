var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/lists/route.js")
R.c("server/chunks/[root-of-the-server]__93954e7d._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(2939)
R.m(22566)
module.exports=R.m(22566).exports
