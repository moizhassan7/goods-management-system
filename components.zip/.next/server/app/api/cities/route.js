var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cities/route.js")
R.c("server/chunks/[root-of-the-server]__f4ab1f5b._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(86581)
R.m(86105)
module.exports=R.m(86105).exports
