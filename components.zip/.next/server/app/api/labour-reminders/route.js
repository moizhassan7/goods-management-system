var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/labour-reminders/route.js")
R.c("server/chunks/[root-of-the-server]__944771f0._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(64171)
R.m(39793)
module.exports=R.m(39793).exports
