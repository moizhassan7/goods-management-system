var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/trips/next-serial/route.js")
R.c("server/chunks/[root-of-the-server]__6866d3a5._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(87993)
R.m(74080)
module.exports=R.m(74080).exports
