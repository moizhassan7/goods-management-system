var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/trips/route.js")
R.c("server/chunks/[root-of-the-server]__a32a6ae1._.js")
R.c("server/chunks/c4e26_next_dist_esm_build_templates_app-route_467540ac.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.c("server/chunks/c4e26_zod_v4_classic_schemas_38dfecf8.js")
R.m(66091)
R.m(88428)
module.exports=R.m(88428).exports
