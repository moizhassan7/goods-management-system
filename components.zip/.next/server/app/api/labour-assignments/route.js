var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/labour-assignments/route.js")
R.c("server/chunks/[root-of-the-server]__2df8bd92._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(86446)
R.m(96927)
module.exports=R.m(96927).exports
