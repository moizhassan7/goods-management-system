var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/labour-assignments/report/route.js")
R.c("server/chunks/[root-of-the-server]__0e9d23c9._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.m(97729)
R.m(75877)
module.exports=R.m(75877).exports
