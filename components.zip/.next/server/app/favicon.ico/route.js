var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__cfb273b5._.js")
R.c("server/chunks/[root-of-the-server]__2c5ac5b2._.js")
R.c("server/chunks/c4e26_next_dist_esm_build_templates_app-route_d91ee7d8.js")
R.m(16051)
R.m(46686)
module.exports=R.m(46686).exports
