__turbopack_load_page_chunks__("/VehicleArrivalPage", [
  "static/chunks/88c3090c369b9449.js",
  "static/chunks/14b6686b431f932f.js",
  "static/chunks/turbopack-2a6774d364469b53.js"
])
