__turbopack_load_page_chunks__("/_app", [
  "static/chunks/04da13ebbef47155.js",
  "static/chunks/14b6686b431f932f.js",
  "static/chunks/turbopack-9d2c26d78575c0a7.js"
])
