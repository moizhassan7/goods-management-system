__turbopack_load_page_chunks__("/_error", [
  "static/chunks/ec24be84d457155d.js",
  "static/chunks/14b6686b431f932f.js",
  "static/chunks/turbopack-448ef70357375b85.js"
])
