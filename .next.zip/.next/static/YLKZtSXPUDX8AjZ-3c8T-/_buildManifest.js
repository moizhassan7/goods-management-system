self.__BUILD_MANIFEST = {
  "/VehicleArrivalPage": [
    "./static/chunks/177b18ef112c7c8b.js"
  ],
  "/_error": [
    "./static/chunks/e2140357751c1c0a.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/VehicleArrivalPage",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()