globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/VehicleArrivalPage": [
      "static/chunks/88c3090c369b9449.js",
      "static/chunks/14b6686b431f932f.js",
      "static/chunks/turbopack-2a6774d364469b53.js"
    ],
    "/_app": [
      "static/chunks/04da13ebbef47155.js",
      "static/chunks/14b6686b431f932f.js",
      "static/chunks/turbopack-9d2c26d78575c0a7.js"
    ],
    "/_error": [
      "static/chunks/ec24be84d457155d.js",
      "static/chunks/14b6686b431f932f.js",
      "static/chunks/turbopack-448ef70357375b85.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5d42197f764f004e.js",
    "static/chunks/f471ac2339220d44.js",
    "static/chunks/743ef0792dd30de1.js",
    "static/chunks/turbopack-fc3757c11b7682f8.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];