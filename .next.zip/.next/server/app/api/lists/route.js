var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/lists/route.js")
R.c("server/chunks/[root-of-the-server]__2f6bd5a4._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(83456)
R.m(69064)
module.exports=R.m(69064).exports
