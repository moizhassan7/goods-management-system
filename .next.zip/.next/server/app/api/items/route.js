var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/items/route.js")
R.c("server/chunks/[root-of-the-server]__7fe7589c._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(84999)
R.m(14213)
module.exports=R.m(14213).exports
