var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/deliveries/route.js")
R.c("server/chunks/[root-of-the-server]__80960203._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(45157)
R.m(63922)
module.exports=R.m(63922).exports
