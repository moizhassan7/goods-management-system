var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/trips/route.js")
R.c("server/chunks/[root-of-the-server]__ea7bcb0f._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_e9d67cd6.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(69216)
R.m(83107)
module.exports=R.m(83107).exports
