var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/vehicles/route.js")
R.c("server/chunks/[root-of-the-server]__1ae9200a._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(16674)
R.m(40874)
module.exports=R.m(40874).exports
