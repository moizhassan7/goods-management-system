var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/agencies/route.js")
R.c("server/chunks/[root-of-the-server]__693bb4b5._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(26065)
R.m(65913)
module.exports=R.m(65913).exports
