var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cities/route.js")
R.c("server/chunks/[root-of-the-server]__45f10a95._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(84319)
R.m(16082)
module.exports=R.m(16082).exports
