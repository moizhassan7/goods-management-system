var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/parties/route.js")
R.c("server/chunks/[root-of-the-server]__d83a2abb._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(78521)
R.m(96055)
module.exports=R.m(96055).exports
